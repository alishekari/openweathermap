get weather json from openweathermap

add this to your django settings:

OPENWEATHERMAP_TOKEN = 'YOUR TOKEN'
